#ifndef __DIRECTION_T_H__
#define __DIRECTION_T_H__

typedef enum {up, right, down, left} direction_t;

#endif